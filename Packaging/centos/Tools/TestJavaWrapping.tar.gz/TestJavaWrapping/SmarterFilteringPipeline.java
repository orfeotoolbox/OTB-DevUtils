/**
 *  Example on the use of the FilteringPipeline
 *
 */


//  Software Guide : BeginLatex
//
//
//  We are going to use the \doxygen{otb}{HarrisImageFilter}
// to find the points of interest in one image.
//
// The derivative computation is performed by a
// convolution with the derivative of a Gaussian kernel of
// variance $\sigma_D$ (derivation scale) and
//     the smoothing of the image is performed by convolving with a
//     Gaussian kernel of variance $\sigma_I$ (integration
// scale). This allows the computation of the following matrix:
//
//   \[
//   \mu(\mathbf{x},\sigma_I,\sigma_D) = \sigma_D^2 g(\sigma_I)\star
//   \left[\begin{array}{cc} L_x^2(\mathbf{x},\sigma_D) &
//   L_xL_y^2(\mathbf{x},\sigma_D)\\ L_xL_y^2(\mathbf{x},\sigma_D)&
//   L_y^2(\mathbf{x},\sigma_D) \end{array}\right]
//   \]
//
//     The output of the detector is $\mathrm{det}(\mu) - \alpha
// \mathrm{trace}^2(\mu)$.
//
// We want to set 3 parameters of this filter through the command line:
// $\sigma_D$ (SigmaD), $\sigma_I$ (SigmaI) and $\alpha$ (Alpha).
//
//
// Let first import the appropriate packages for readers, Harris image filter 
// and rescaler :
//
//  Software Guide : EndLatex

// Software Guide : BeginCodeSnippet
import org.otb.otbio.*;
import org.otb.otbfeatureextraction.*;
import org.itk.itkintensityfilters.*;



public class SmarterFilteringPipeline
{
    public static void main( String argv[] )
    {
       // Software Guide : EndCodeSnippet
      
       System.out.println("Smarter Filtering Pipeline Tutorial");
       
       //  Software Guide : BeginLatex
       //
       //  Now, we can declare the image type, the reader and the writer as
       //  before:
       //
       //  Software Guide : EndLatex
      
       // Software Guide : BeginCodeSnippet
       
       otbImageFileReaderID2   reader = new otbImageFileReaderID2();
       otbStreamingImageFileWriterIUC2 writer = 
         new otbStreamingImageFileWriterIUC2();

       // Software Guide : EndCodeSnippet

       //  Software Guide : BeginLatex
       //
       //  We are getting the filenames for the input and the output
       //  images directly from the command line:
       //
       //  Software Guide : BeginLatex

       reader.SetFileName(argv[0]);
       writer.SetFileName(argv[1]);
       
       //  Software Guide : BeginLatex
       //
       // Now we have to declare the filter. It is templated with the
       // input image type and the output image type like many filters
       // in OTB. Here we are using the same type for the input and the
       // output images:
       // Since the image type used is otb::Image<float,2>, and the mangling
       // for this image types is IF2, the harris filter used will be : 
       //
       //  Software Guide : EndLatex
       
       // Software Guide : BeginCodeSnippet
       otbHarrisImageFilterID2ID2 harrisFilter = new otbHarrisImageFilterID2ID2();
       // Software Guide : EndCodeSnippet
       
       //  Software Guide : BeginLatex
       //
       //  We set the filter parameters from the input command line.
       //
       //  Software Guide : EndLatex
       
       // Software Guide : BeginCodeSnippet
       
       harrisFilter.SetSigmaD(Double.parseDouble(argv[2]));
       harrisFilter.SetSigmaI(Double.parseDouble(argv[3]));
       harrisFilter.SetAlpha(Double.parseDouble(argv[4]));

       // Software Guide : EndCodeSnippet
       
       //  Software Guide : BeginLatex
       //
       // We add the rescaler filter as before
       //
       //  Software Guide : EndLatex
       
       // Software Guide : BeginCodeSnippet
       itkRescaleIntensityImageFilterID2IUC2 
           rescaleFilter = new itkRescaleIntensityImageFilterID2IUC2();
       
       short minimum = 0;
       short maximum = 255;
       rescaleFilter.SetOutputMinimum(minimum);
       rescaleFilter.SetOutputMaximum(maximum);
       // Software Guide : EndCodeSnippet

       //  Software Guide : BeginLatex
       //
       // Let's plug the pipeline:
       //
       //  Software Guide : EndLatex

       // Software Guide : BeginCodeSnippet
       harrisFilter.SetInput( reader.GetOutput() );
       rescaleFilter.SetInput( harrisFilter.GetOutput() );
       writer.SetInput( rescaleFilter.GetOutput() );
           // Software Guide : EndCodeSnippet
       
       //  Software Guide : BeginLatex
       //
       // We trigger the pipeline execution calling the \code{Update()}
       // method on the writer
       //
       //  Software Guide : EndLatex
       
       // Software Guide : BeginCodeSnippet
       writer.Update();
        // Software Guide : EndCodeSnippet
    }

}


