/**
 *  Example on the use of the HelloWorld
 *
 */

//  Software Guide : BeginLatex
//
//  The following code is an implementation of a small OTB
//  program. It tests including header files and linking with required
//  packages.
//
//  Software Guide : EndLatex

// Software Guide : BeginCodeSnippet
import org.otb.otbimages.*;

public class HelloWorldOTB
{
    public static void main( String argv[] )
    {
       otbImageUS2  image = new otbImageUS2();
       System.out.println("OTB Hello World !");
    }
}
// Software Guide : EndCodeSnippet

//  Software Guide : BeginLatex
//
//  This code instantiates an image whose pixels are represented with
//  type \code{unsigned short}. The new keyword defines a new instance
//  of otb::Image.
//
//  Software Guide : EndLatex
