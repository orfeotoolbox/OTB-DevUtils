//  Software Guide : BeginCommandLineArgs
//    INPUTS: {QB_Suburb.png}
//    OUTPUTS: {TutorialsFilteringPipelineOutput.png}
//  Software Guide : EndCommandLineArgs


//  Software Guide : BeginLatex
//
//
// We are going to use the \doxygen{itk}{GradientMagnitudeImageFilter}
// to compute the gradient of the image. The begining of the file is
// similar to the Pipeline.java.
//
// We import the required packages:
//
//  Software Guide : EndLatex

// Software Guide : BeginCodeSnippet
import org.otb.otbio.*;
import org.itk.itkfiltering.*;
// Software Guide : EndCodeSnippet

public class FilteringPipeline
{
    public static void main( String argv[] )
    {
       System.out.println("Filtering Pipeline Tutorial");

       //  Software Guide : BeginLatex
       //
       //  We declare the reader and the writer as
       //  before:
       //
       //  Software Guide : EndLatex

       // Software Guide : BeginCodeSnippet
       otbImageFileReaderIUS2          reader = new otbImageFileReaderIUS2();
       otbStreamingImageFileWriterIUS2 writer = new otbStreamingImageFileWriterIUS2();
       // Software Guide : EndCodeSnippet

       //  Software Guide : BeginLatex
       //
       //  Now we declare the GradientMagnitudeFilter:
       //
       //  Software Guide : EndLatex

       // Software Guide : BeginCodeSnippet
       itkGradientMagnitudeImageFilterIUS2IUS2 filter = 
           new itkGradientMagnitudeImageFilterIUS2IUS2();
       // Software Guide : EndCodeSnippet

       //  Software Guide : BeginLatex
       //
       //  We set the file names for the reader and the writer:
       //
       //  Software Guide : EndLatex

       // Software Guide : BeginCodeSnippet   
       reader.SetFileName( argv[0] );
       writer.SetFileName( argv[1] );
       // Software Guide : EndCodeSnippet

       //  Software Guide : BeginLatex
       //
       // Let's plug the pipeline:
       //
       //  Software Guide : EndLatex

       // Software Guide : BeginCodeSnippet
       filter.SetInput( reader.GetOutput() );
       writer.SetInput( filter.GetOutput() );
       // Software Guide : EndCodeSnippet
   
       //  Software Guide : BeginLatex
       //
       // And finally, we trigger the pipeline execution calling the \code{Update()}
       // method on the writer
       //
       //  Software Guide : EndLatex
    
       // Software Guide : BeginCodeSnippet 
       writer.Update();
       // Software Guide : EndCodeSnippet
    }

}


