/**
 *  Example on the use of the SVMImageModelEstimator
 *
 */


//  Software Guide : BeginLatex
// This example illustrates the use of the
// \doxygen{otb}{SVMImageModelEstimator} class. This class allows the
// estimation of a SVM model (supervised learning) from a feature
// image and an image of labels. In this example, we will train an SVM
// to separate between water and non-water pixels by using the RGB
// values only. 
// The first thing to do import the appropriate package where the class is
// definied.
//
//  Software Guide : EndLatex


import org.otb.otbio.*;

//  Software Guide : BeginCodeSnippet
import org.otb.otblearning.*;
//  Software Guide : EndCodeSnippet


public class SVMImageModelEstimator
{
    public static void main( String argv[] )
    {
       //  Software Guide : BeginLatex
       //
       //  We define the reader for the input and training images. Even if the
       //  input image will be an RGB image, we can read it as a 3 component
       //  vector image. This simplifies the interfacing with OTB's SVM
       //  framework.
       //
       // Software Guide : EndLatex
       //  Software Guide : BeginCodeSnippet
       otbImageFileReaderVIUC2  inputReader = new otbImageFileReaderVIUC2();    
       otbImageFileReaderIUC2 trainingReader = new otbImageFileReaderIUC2();  
       //  Software Guide : EndCodeSnippet
       
       // Software Guide : BeginLatex
       //
       // Set the filenames for the readers.
       // 
       // Software Guide : EndLatex
       //  Software Guide : BeginCodeSnippet
       inputReader.SetFileName(argv[0]);
       trainingReader.SetFileName(argv[1]);
       //  Software Guide : EndCodeSnippet

       //  Software Guide : BeginLatex
       //
       //  The \doxygen{otb}{SVMImageModelEstimator} class is templated over
       //  the input (features) and the training (labels) images. Note that the 
       //  refers to an\doxygen{otb}{Vector} for the images of features and the
       //  \doxygen{otb}{Image} for labels image. Both of them templated with 
       //  unsigned char pixel type.
       //
       // Software Guide : EndLatex
       //  Software Guide : BeginCodeSnippet
       otbSVMImageModelEstimatorVIUC2IUC2 svmEstimator = new otbSVMImageModelEstimatorVIUC2IUC2();
       //  Software Guide : EndCodeSnippet

       //  Software Guide : BeginLatex
       //
       //  We can now set the model estimator parameters.
       //
       // Software Guide : EndLatex
       //  Software Guide : BeginCodeSnippet
       svmEstimator.SetInputImage( inputReader.GetOutput() );
       svmEstimator.SetTrainingImage( trainingReader.GetOutput() );
       svmEstimator.SetNumberOfClasses( 2 );
       
       //  Software Guide : EndCodeSnippet

       //  Software Guide : BeginLatex
       //
       //  The model estimation procedure is triggered by calling the
       //  estimator's \code{Update} method.
       //
       // Software Guide : EndLatex
       //  Software Guide : BeginCodeSnippet
       
       svmEstimator.Update();
       //  Software Guide : EndCodeSnippet

       //  Software Guide : BeginLatex
       //
       //  Finally, the estimated model can be saved to a file for later use.
       //
       //  Software Guide : EndLatex
       //  Software Guide : BeginCodeSnippet
       svmEstimator.SaveModel(argv[2]);
       //  Software Guide : EndCodeSnippet
    }
}
