/**
 *  Example on the use of the Pipeline
 *
 */


//  Software Guide : BeginCommandLineArgs
//    INPUTS: {QB_Suburb.png}
//    OUTPUTS: {TutorialsPipelineOutput.png}
//  Software Guide : EndCommandLineArgs


//  Software Guide : BeginLatex
//
//  Start by including some  required packages and with the
//  usual \code{main} declaration:
//
//  Software Guide : EndLatex

// Software Guide : BeginCodeSnippet
import org.otb.otbio.*;

public class Pipeline
{
  public static void main( String argv[] )
  {
  // Software Guide : EndCodeSnippet
      
  //  Software Guide : BeginLatex
  //
  //  To read the image, we need an ImageFileReaderIUC2. This reader is templated
  // over an otb::Image. The pixel type is is declared as an unsigned char (one byte) and the image is 
  // specified as having 2 dimensions.
  //
  //  Software Guide : EndLatex
      System.out.println("Pipeline Tutorial");
  // Software Guide : BeginCodeSnippet
   otbImageFileReaderIUC2          reader = new otbImageFileReaderIUC2();
   
  // Software Guide : EndCodeSnippet

  //  Software Guide : BeginLatex
  //
  // Then, we need an \doxygen{otb}{StreamingImageFileWriter}
  // also templated with the image type.
  //
  //  Software Guide : EndLatex

  // Software Guide : BeginCodeSnippet
    otbStreamingImageFileWriterIUC2 writer = new otbStreamingImageFileWriterIUC2();
 // Software Guide : EndCodeSnippet

  //  Software Guide : BeginLatex
  //
  // The filenames are passed as arguments to the program. We keep it
  // simple for now and we don't check their validity.
  //
  //  Software Guide : EndLatex

  // Software Guide : BeginCodeSnippet
    reader.SetFileName( argv[0] );
    writer.SetFileName( argv[1] );
  // Software Guide : EndCodeSnippet

  //  Software Guide : BeginLatex
  //
  // Now that we have all the elements, we connect the pipeline,
  // pluging the output of the reader to the input of the writer.
  //
  //  Software Guide : EndLatex

  // Software Guide : BeginCodeSnippet
    writer.SetInput( reader.GetOutput() );
  // Software Guide : EndCodeSnippet

  //  Software Guide : BeginLatex
  //
  // And finally, we trigger the pipeline execution calling the Update()
  // method on the last element of the pipeline. The last element will make
  // sure to update all previous elements in the pipeline.
  //
  //  Software Guide : EndLatex

  // Software Guide : BeginCodeSnippet
    writer.Update();
  // Software Guide : EndCodeSnippet
  }

}


