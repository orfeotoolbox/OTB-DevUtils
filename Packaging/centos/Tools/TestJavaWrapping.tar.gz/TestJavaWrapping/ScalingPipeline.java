/**
 *  Example on the use of the FilteringPipeline
 *
 */

//  Software Guide : BeginCommandLineArgs
//    INPUTS: {QB_Suburb.png}
//    OUTPUTS: {TutorialsScalingPipelineOutput.png}
//  Software Guide : EndCommandLineArgs


//  Software Guide : BeginLatex
//
//  This example illustrates the use of the
// \doxygen{itk}{RescaleIntensityImageFilter} to convert
// the result for proper display.
//
// We include the required packages importing the packages
// for the \doxygen{itk}{CannyEdgeImageFilter} and the
// \doxygen{itk}{RescaleIntensityImageFilter}.
//
//  Software Guide : EndLatex

// Software Guide : BeginCodeSnippet
import org.otb.otbio.*;
import org.itk.itkedgesandcontours.*;
import org.itk.itkintensityfilters.*;

public class ScalingPipeline
{
  public static void main( String argv[] )
  {
    System.out.println("Scaling Pipeline Tutorial");
    // Software Guide : EndCodeSnippet
    
    //  Software Guide : BeginLatex
    //
    //  Since this example aims to write theoutput image with a different type
    // than the input type image, one declare the reader and the writer with different 
    // types.
    //
    //  Software Guide : EndLatex
    
    // Software Guide : BeginCodeSnippet
    otbImageFileReaderIF2           reader = new otbImageFileReaderIF2();
    otbStreamingImageFileWriterIUC2 writer = new otbStreamingImageFileWriterIUC2();
    
    reader.SetFileName( argv[0] );
    writer.SetFileName( argv[1] );

    // Software Guide : EndCodeSnippet
    
    //  Software Guide : BeginLatex
    //
    // Now we are declaring the edge detection filter which is going to work with
    // float input and output.
    //
    //  Software Guide : EndLatex
    
    // Software Guide : BeginCodeSnippet
    itkCannyEdgeDetectionImageFilterIF2IF2 
       cannyFilter = new itkCannyEdgeDetectionImageFilterIF2IF2();
    
    // Software Guide : EndCodeSnippet
    
    //  Software Guide : BeginLatex
    //
    // Here comes the interesting part: we declare the
    // \doxygen{itk}{RescaleIntensityImageFilter}. The input
    // image type is the output type of the edge detection
    // filter. The output type is the same as the input type
    // of the writer.
    //
    // Desired minimum and maximum values for the output are
    // specified by the methods \code{SetOutputMinimum()} and
    // \code{SetOutputMaximum()}.
    //
    // This filter will actually rescale all the pixels of
    // the image but also cast the type of these pixels.
    //
    //  Software Guide : EndLatex

  // Software Guide : BeginCodeSnippet
    itkRescaleIntensityImageFilterIF2IUC2 
       rescaleFilter = new itkRescaleIntensityImageFilterIF2IUC2();

    short minimum = 0;
    short maximum = 255;
        
    rescaleFilter.SetOutputMinimum(minimum);
    rescaleFilter.SetOutputMaximum(maximum);

    // Software Guide : EndCodeSnippet

    //  Software Guide : BeginLatex
    //
    // Let's plug the pipeline:
    //
    //  Software Guide : EndLatex

    // Software Guide : BeginCodeSnippet
    cannyFilter.SetInput( reader.GetOutput() );
    rescaleFilter.SetInput( cannyFilter.GetOutput() );
    writer.SetInput( rescaleFilter.GetOutput() );
    // Software Guide : EndCodeSnippet
    
    //  Software Guide : BeginLatex
    //
    // And finally, we trigger the pipeline execution calling the \code{Update()}
    // method on the writer
    //
    //  Software Guide : EndLatex
    
    // Software Guide : BeginCodeSnippet
    writer.Update();
    // Software Guide : EndCodeSnippet
  }
}


